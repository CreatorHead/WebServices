package com.google.googlemaps.rest;

import java.net.URI;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import com.google.googlemaps.dao.UserData;

@Path("/user_service")
public class UserServices 
{
	//@PUT
	@POST
	@Path("/create")
	@Consumes(MediaType.APPLICATION_XML)
	public Response createUser(UserData data)
	{
		System.out.println("User ID : "+data.getUserID());
		System.out.println("User Name : "+data.getUserName());
		//Business Logic to insert the Data into DB
		
		ResponseBuilder rb = Response.created(URI.create("user_service/read/"+data.getUserID()));
		Response resp = rb.build();
		
		return resp;
	}//End of createUser
	
	@GET
	@Path("/read/{id}")
	@Produces(MediaType.APPLICATION_XML)
	public Response getUser(@PathParam("id") int userID)
	{
		System.out.println("GET :: User ID :- "+userID);
		//Logic to Get the Data from DB
		UserData data = new UserData();
		data.setUserID(123);
		data.setUserName("Praveen");
		return Response.status(200).entity(data).build();
	}//End of getUser
	
	
	@POST
	@Path("/update")
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.APPLICATION_JSON)
	public Response updateUser(UserData data)
	{
		System.out.println("POST :: User ID :- "+data.getUserID());
		System.out.println("POST :: User Name :- "+data.getUserName());
		//Logic to Update the Data from DB
		UserData updatedData = new UserData();
		updatedData.setUserID(123);
		updatedData.setUserName("Praveen D");
		return Response.status(200).entity(updatedData).build();
	}//End of updateUser
	
	@DELETE
	@Path("/delete/{id}")
	public void deleteUser(@PathParam("id") int userID)
	{
		System.out.println("DELETE :: User ID :- "+userID);
		//Logic to Delete the Data from DB
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}//End of Class
