package com.google.googlemaps.rest;

import java.util.Set;

import javax.ws.rs.CookieParam;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.FormParam;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.MatrixParam;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;

import com.google.googlemaps.dao.MyCustomClass;

public class MyBeanParam 
{
	@PathParam("location")
	private MyCustomClass myclass;
	
	
	private boolean state;
	
	@QueryParam("country")
	private Set<Byte> country_Code;
	
	@FormParam("knownFor") @DefaultValue("1")
	private short known;
	
	@CookieParam("myName")
	private String name;
	
	@CookieParam("myLocation")
	private String myLoc;
	
	@MatrixParam("geoCode")
	private int code;
	
	@HeaderParam("MyHostNM") 
	private double hostNM;

	public MyCustomClass getMyclass() {
		return myclass;
	}

	public void setMyclass(MyCustomClass myclass) {
		this.myclass = myclass;
	}

	
	public boolean isState() {
		return state;
	}

	@QueryParam("state")
	public void setState(boolean state) {
		this.state = state;
	}

	public Set<Byte> getCountry_Code() {
		return country_Code;
	}

	public void setCountry_Code(Set<Byte> country_Code) {
		this.country_Code = country_Code;
	}

	public short getKnown() {
		return known;
	}

	public void setKnown(short known) {
		this.known = known;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMyLoc() {
		return myLoc;
	}

	public void setMyLoc(String myLoc) {
		this.myLoc = myLoc;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public double getHostNM() {
		return hostNM;
	}

	public void setHostNM(double hostNM) {
		this.hostNM = hostNM;
	}
	
	
}
