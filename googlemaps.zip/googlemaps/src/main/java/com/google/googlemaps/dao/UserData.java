package com.google.googlemaps.dao;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="user-data")
@XmlAccessorType(XmlAccessType.FIELD)
public class UserData 
{
	@XmlElement(name="userid")
	private int userID;
	
	@XmlElement(name="username")
	private String userName;

	public int getUserID() {
		return userID;
	}

	public void setUserID(int userID) {
		this.userID = userID;
	}


	@Override
	public String toString() {
		return "UserData [userID=" + userID + ", userName=" + userName + "]";
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
	

	
}
