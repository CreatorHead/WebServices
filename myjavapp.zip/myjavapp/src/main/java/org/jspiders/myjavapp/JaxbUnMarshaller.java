package org.jspiders.myjavapp;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

public class JaxbUnMarshaller 
{
	public static void main(String[] args) 
	{
		try 
		{
			JAXBContext jaxbContext 
				= JAXBContext.newInstance(Employee.class);
			Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
			Employee data = (Employee)unmarshaller.unmarshal(new FileReader("employee.xml"));
			
			System.out.println("Data In XML ...");
			System.out.println("Emp Name : "+data.getName());
			System.out.println("Emp ID : "+data.getId());
			System.out.println("Emp Salary : "+data.getSalary());
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		
		
		
		
		
	}
}
