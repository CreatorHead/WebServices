package org.jspiders.myjavapp;

import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;

public class JaxbMarshaller 
{
	public static void main(String[] args) 
	{
		try 
		{
			Employee emp1 = new Employee();
			emp1.setId(1234);
			emp1.setName("Praveen");
			emp1.setSalary(100.20f);
			emp1.setNumbers(new long[]{123465789l, 987654321l});
			
			Employee emp2 = new Employee();
			emp2.setId(4567);
			emp2.setName("Naveen");
			emp2.setSalary(100.20f);
			emp2.setNumbers(new long[]{123465789l, 987654321l});
			
			
			List<Employee> empList = new ArrayList<Employee>();
			empList.add(emp1);
			empList.add(emp2);
			
			Company cmp = new Company();
			cmp.setEmpList(empList);
			
			JAXBContext jaxbContext 
				= JAXBContext.newInstance(Company.class);
			
			Marshaller marshaller = jaxbContext.createMarshaller();
			marshaller.setProperty(marshaller.JAXB_FORMATTED_OUTPUT, true);
			marshaller.marshal(cmp, System.out);
			marshaller.marshal(cmp, new FileOutputStream("company.xml"));
			System.out.println("Cretaed the File");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		
		
		
		
		
	}
}
