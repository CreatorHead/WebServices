package org.jspiders.myjavapp;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

import org.jspiders.pojo.GenerateGoogleResponseData;
import org.jspiders.pojo.GeocodeResponse;

import com.google.gson.Gson;

public class GSON_Json2Java 
{
	public static void main(String[] args)  
	{
		Gson gson = new Gson();
		GeocodeResponse resp = null;
		try( FileReader reader 
			   = new FileReader("GoogleResponse.json") )
		{
			resp = gson.fromJson(reader, GeocodeResponse.class);
		}catch(Exception e){
			e.printStackTrace();
		}
		System.out.println(resp);
	}//End of Main
}//End of Class






