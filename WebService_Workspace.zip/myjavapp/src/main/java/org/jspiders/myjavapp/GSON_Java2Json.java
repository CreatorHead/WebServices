package org.jspiders.myjavapp;

import java.io.File;
import java.io.FileWriter;

import org.jspiders.pojo.GenerateGoogleResponseData;
import org.jspiders.pojo.GeocodeResponse;

import com.google.gson.Gson;

public class GSON_Java2Json 
{
	public static void main(String[] args) 
	{
		GeocodeResponse ref 
		 = GenerateGoogleResponseData.generateData();
		
		Gson gson = new Gson();
		String json = gson.toJson(ref);
		System.out.println("JSON :- ");
		System.out.println(json);
		
		File f = new File("GoogleResponse.json");
		try( FileWriter wr = new FileWriter(f) )
		{
			gson.toJson(ref, wr);
		}catch(Exception e){
			e.printStackTrace();
		}
		System.out.println("Created the File ...");
	}//End of Main
}//End of Class






